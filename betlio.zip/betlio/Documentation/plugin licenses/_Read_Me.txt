---------------------------------------------------------------------------
This folder contains the licenses ​​of the source and plugins we use.
You can get more information about the sources on the documentation file.
---------------------------------------------------------------------------